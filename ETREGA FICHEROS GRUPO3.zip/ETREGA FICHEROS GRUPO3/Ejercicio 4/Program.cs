﻿namespace Ejercicio_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*            (4) Teniendo un fichero con los datos de las notas de alumnado:
                    https://tinyurl.com/ycc27blx
                        Nos interesa tratar las notas del alumnado que está situado en las posiciones impares del fichero, no de las pares.
                   Las tres primeras notas son de los ejercicios entregados: su media puntúa un 30 % sobre la nota final.
                   Las tres siguientes notas siguientes son de las intervenciones en clase: su media puntúa un 20 % sobre la nota final.
                   Las dos últimas notas son notas de los exámenes realizados: su media en un 50 % de la nota final.
                   La nota final calculada se trunca en todos los casos al entero inferior.
                   En un nuevo fichero llamado “salida.txt”, se escribe el nombre del alumno/ a y la nota final que tenga, separados por un punto y coma.*/
            List<string> nombres=new List<string>();
            List<int> notas=new List<int>();
            string salida = "salida.txt";
      /*      COMPROBAR EXISTENCIA FICHERO*/
            if (!File.Exists(CSFunciones.FICHERO))
                Console.WriteLine("Lo siento,arquivo no encontrado.");
            else
            {
                CSFunciones.ObtenerNombresFichero(ref nombres);
                CSFunciones.ObtenerNotasFichero(ref notas);
                CSFunciones.CrearSalida(ref nombres,ref notas,ref salida);
            }



         }
    }
}
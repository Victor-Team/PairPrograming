﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    internal class CSFunciones
    {
        public const string FICHERO = "Datos notas.csv";
        public static List<string> ObtenerNombresFichero(ref List<string> nombres)
        {
            int i = 1;
            string aux;
            string[] aux2 =new string[0];
            StreamReader sr = new StreamReader(FICHERO);
            try
            {
                while(!sr.EndOfStream)
                {
                    if (i%2!=0)
                    {
                        aux = sr.ReadLine();
                        aux2 = aux.Split(";");
                        nombres.Add(aux2[0]);
                    }
                    else
                        sr.ReadLine();
                    i++;
                }
                sr.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return nombres;
        }
        public static List<int> ObtenerNotasFichero(ref List<int> notas)
        {
            decimal media1 = 0,media2=0,media3 = 0;
            decimal sumaMedias = 0;
            int suma = 0, notaFinal=0,i=1;
            string aux;
            string[] aux2=new string[0];
            StreamReader sr = new StreamReader(FICHERO);
            try
            {
                while (!sr.EndOfStream)
                {

                    if (i % 2 != 0)
                    {
                        aux = sr.ReadLine();
                        aux2 = aux.Split(";");
                        foreach (string s in aux2)
                        {
                            suma = 0;
                            for (int j = 1; j < 4; j++)
                            {
                                suma += Convert.ToInt32(aux2[j]);
                            }
                            media1 = (Convert.ToDecimal(suma) / 3) * 0.3m;
                            suma = 0;
                            for (int j = 4; j < 7; j++)
                            {
                                suma += Convert.ToInt32(aux2[j]);
                            }
                            media2 = (Convert.ToDecimal(suma) / 3) * 0.2m;
                            suma = 0;
                            for (int j = 7; j < 9; j++)
                            {
                                suma += Convert.ToInt32(aux2[j]);
                            }
                            media3 = (Convert.ToDecimal(suma) / 2) * 0.5m;
                            suma = 0;
                            sumaMedias = media1 + media2 + media3;
                        }
                        notaFinal = Convert.ToInt32(Math.Truncate(sumaMedias));
                        notas.Add(notaFinal);
                    }
                    else
                        sr.ReadLine();
                    i++;
                }
                sr.Close(); 
                
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return notas;
        }
        public static string CrearSalida(ref List<string> nombres, ref List<int>notas,ref string salida)
        {
            try
            {
                File.CreateText(salida);
                StreamWriter sw = File.CreateText(salida);
                for (int i = 0; i < nombres.Count; i++)
                {
                    sw.WriteLine(nombres[i] + ";" + notas[i]);
                }
                sw.Close();
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return salida;
        }
    }

}

﻿using System.ComponentModel.Design;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Runtime.ConstrainedExecution;

namespace Ejercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
         /*   (3) Se dispone del fichero paro.csv que presenta el número de personas en paro.
       El fichero lo podemos ver en:
                                                                                        https://bit.ly/2H6fm48
            En cada una de las líneas del fichero se presenta un municipio en concreto de Canarias. 
         En cada línea, se presentan datos de un mes y año concreto colocando como título del campo “AMBOSSEXOS_PERIODO_MESAÑO” como por ejemplo 
         “AMBOSSEXOS_PERIODO_SEPTIEMBRE2009”. 
       
       Queremos pasar esta información a un fichero “SALIDA.TXT” en el que se traslade la información al formato:
            AÑO; MES; MUNICIPIO; DATO

            Eso implica que, por cada línea del fichero inicial, se deben generar 126 líneas en el nuevo fichero.

       En este fichero final se debe colocar como primera línea, la línea de formato antes indicada: AÑO; MES; MUNICIPIO; DATO

       Si da error la lectura del fichero inicial o la escritura del fichero final, se saldrá del programa mostrando el error correspondiente.
       Si la cantidad de personas en paro de ese mes no es un valor numérico, no se coloca ese mes en el fichero final y se pasa a la cantidad siguiente.*/

            bool noerror=true;
            string SALIDA = "salida.txt";
            string[] datosCompletos=new string[0];
            string[] meses=new string[0];
            string[] agno=new string[0];
            string[] municipios = new string[0];
            int[] datosMunicipio=new int[0];
            int cont = 0;

            /*  COMPROBAR QUE EL FICHERO EXISTE*/
            if (!File.Exists(CSFunciones.FICHERO))
            {
                Console.WriteLine("Lo siento, archivo no encontrado");
                Console.WriteLine("Presione una tecla para salir del programa.");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Fichero " + CSFunciones.FICHERO + " encontrado.");
                Console.WriteLine("Pulse una tecla para continuar");
                Console.ReadKey();
                Console.Clear();

                /*            OBTENER UN STRING[] CON CADA LINEA EN UNA POSICION*/
                datosCompletos = CSFunciones.ObtenerDatos(ref datosCompletos);

                /*            GUARTAR EL MES Y EL AÑO EN UN STRING[] PARA CADA DATO*/
                CSFunciones.ObtenerMesAgno(ref datosCompletos, ref meses, ref agno);

                /*GUARDAR CADA NOMBRE DE CADA MUNICIPIO EN UN STRING*/
                CSFunciones.ObtenerMunicipios(ref datosCompletos, ref municipios);

                /*CREAR FICHERO SALIDA.TXT*/
                StreamWriter sw = File.CreateText(SALIDA);
                for (int j = 0; j < municipios.Length; j++)
                {
                    cont++;
                    datosMunicipio = CSFunciones.ObtenerDatosParoMunicipio(ref datosCompletos, ref cont);
                    for (int i = 0; i < datosMunicipio.Length; i++)
                    {
                        sw.WriteLine(agno[i] + ";" + meses[i] + ";" + municipios[j] + ";" + datosMunicipio[i]);
                    }
                }
                sw.Close();

                Console.WriteLine("Si se muestra este mensaje es que todo ha ido correctamente.");
                Console.WriteLine("Pulse una tecla para mostrar el fichero: " + CSFunciones.FICHERO);
                Console.ReadKey();
                Console.Clear();
                CSFunciones.MostrarSalida(ref SALIDA);
            }




        }
    }
}
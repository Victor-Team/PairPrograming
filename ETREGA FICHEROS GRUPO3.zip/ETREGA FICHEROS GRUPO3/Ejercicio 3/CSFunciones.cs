﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    internal class CSFunciones
    {
        public const string FICHERO = "paro.csv";
        /*public static bool FicheroValido()
        {
            bool valor = true;
            try
            {
                if (!File.Exists(FICHERO))
                {
                    Console.WriteLine("Lo siento, archivo no encontrado");
                    Console.WriteLine("Presione una tecla para salir del programa.");
                    Console.ReadKey();
                }
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
                valor = false;
            }
            return valor;
        }*/
        public static string[] ObtenerDatos(ref string[] datosCompletos)
        {
            try
            {
                StreamReader sr = new StreamReader(FICHERO);
                while(!sr.EndOfStream)
                {
                    Array.Resize(ref datosCompletos, datosCompletos.Length + 1);
                    datosCompletos[datosCompletos.Length - 1] = sr.ReadLine();
                }
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return datosCompletos;
        }
        public static void ObtenerMesAgno(ref string[] datosCompletos,ref string[] meses,ref string[] agno)
        {
            int k = 0,l=0;
            string[] aux=new string[0];
            string[] aux2 = new string[0];
            string[] mesagno = new string[0];
            try
            {
                if (k==0)
                {
                    aux = datosCompletos[k].Split(",");
                }
                for (int i = 6; i < aux.Length-1; i++)/* ¡¡¡  i=6 xk es a partir se la sexta columna ; AUX.LENGTH - 1 XK LA ULTIMA COLUMNA ES UN 126!!!*/
                {
                    aux2 = aux[i].Split("_");
                    for (int j = 2; j < aux2.Length; j++)
                    {
                        Array.Resize(ref mesagno, mesagno.Length + 1);
                        mesagno[mesagno.Length - 1] = aux2[j];
                    }
                }
                meses = new string[mesagno.Length];
                agno = new string[mesagno.Length];
                foreach (string a in mesagno)
                {
                    foreach (char caracter in a)
                    {
                        if (Char.IsDigit(caracter))
                            agno[l] += caracter;
                        else
                        {
                            if (Char.IsLetter(caracter))
                                meses[l] += caracter;
                        }
                    }
                    l++;
                }

            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static string[] ObtenerMunicipios(ref string[] datosCompletos,ref string[] municipios)
        {
            municipios = new string[datosCompletos.Length-1];
            string[] aux=new string[datosCompletos.Length-1];
            const int K=5;
            int l=0;
            try
            {
                for (int i=1; i<datosCompletos.Length; i++)
                {
                    aux = datosCompletos[i].Split(",");
                    municipios[l]=aux[K];
                    l++;
                }
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return municipios;
        }
        public static int[] ObtenerDatosParoMunicipio(ref string[] datosCompletos,ref int cont)
        {
            int[] datosMunicipio = new int[0];
            string[] aux=new string[0];
            int aux2 = 0;
            try
            {
                aux = datosCompletos[cont].Split(",");
                for (int j=6; j<aux.Length; j++)
                {
                    if (aux[j] != null && int.TryParse(aux[j], out aux2))
                    {
                        Array.Resize(ref datosMunicipio, datosMunicipio.Length + 1);
                        datosMunicipio[datosMunicipio.Length - 1] = Convert.ToInt32(aux[j]);
                    }
                }
                
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return datosMunicipio;
        }
        public static void MostrarSalida(ref string SALIDA)
        {
            try
            {
                StreamReader sr = new StreamReader(SALIDA);
                while(!sr.EndOfStream)
                    Console.WriteLine(sr.ReadLine());
                sr.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}

﻿using static System.Net.Mime.MediaTypeNames;
using System.Diagnostics.Metrics;
using System.Net;

namespace Ejercicio_1
{
    internal class Program
    {
        public static string FICHERO1 = "1.txt";
        public static string FICHERO2 = "2.txt";
        static void Main(string[] args)
        {
            /*            (1) Partiendo de dos ficheros con nombre 1.txt y 2.txt, comparar ambos ficheros línea a línea. Se debe contar cuántas líneas son iguales entre ambos ficheros. 
                        Si las líneas de los ficheros son diferentes, se introducirán en un nuevo fichero denominado diferencias.txt en el que se pondrá el número de la línea donde son diferentes,
                        el contenido de esa línea en el primer fichero y el contenido de esa línea del segundo fichero.Estos tres elementos irán separados por un punto y coma.
                        Al finalizar el tratamiento de ambos ficheros, se mostrará el número de de líneas que eran iguales, así como el contenido del fichero diferencias.txt.
                    }*/
            List <string> fichero1= new List<string>();
            List <string> fichero2= new List<string>();
            bool noerror=true;
            int lineasIguales = 0;
            string NUEVOFICHERO = "diferencias.txt";
            StreamReader sr;
            if (File.Exists(FICHERO1) && File.Exists(FICHERO2))
            {
                noerror=CSFunciones.AnalizarFicheros(ref FICHERO1,ref FICHERO2,ref fichero1, ref fichero2);
            }
            else
                Console.WriteLine("Lo siento, uno o los dos archivos introducidos no existen, vuelva a probar.");

            noerror =  CSFunciones.CompararVectores(ref fichero1, ref fichero2, ref NUEVOFICHERO, ref lineasIguales) ;
            Console.WriteLine("Si se muestra este mensaje es que todo ha ido correctamente.");
            Console.WriteLine("Pulse una tecla para mostrar el número de líneas iguales y el nuevo el fichero: " +NUEVOFICHERO);
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Líneas iguales: "+lineasIguales+"\n");
            sr = new StreamReader(NUEVOFICHERO);
            while(!sr.EndOfStream)
                Console.WriteLine(sr.ReadLine());
            }

        }

    
}

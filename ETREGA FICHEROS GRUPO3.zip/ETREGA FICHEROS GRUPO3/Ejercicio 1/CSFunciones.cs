﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    internal class CSFunciones
    {
        public static bool AnalizarFicheros(ref string FICHERO1, ref string FICHERO2,ref List<string> fichero1, ref List<string> fichero2)
        {
            bool valor = true;
            int i=0;
            StreamReader sr1 = new StreamReader(FICHERO1);
            StreamReader sr2 = new StreamReader(FICHERO2);
            try
            {
                while (!sr1.EndOfStream || !sr2.EndOfStream)
                {
                    if (!sr1.EndOfStream && !sr2.EndOfStream)
                    {
                        fichero1.Add(sr1.ReadLine());
                        fichero2.Add(sr2.ReadLine());
                    }
                    else
                    {
                        if (sr1.EndOfStream && !sr2.EndOfStream)
                        { 
                            fichero1.Add("");
                            fichero2.Add(sr2.ReadLine());
                        }
                        else
                        {
                            if (!sr1.EndOfStream && sr2.EndOfStream)
                            {
                                fichero1.Add(sr1.ReadLine());
                                fichero2.Add("");
                            }
                        }
                    }

                 }
                sr1.Close();
                sr2.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                valor = false;
            }
            return valor;
        }
        public static bool CompararVectores(ref List<string> fichero1, ref List<string> fichero2, ref string NUEVOFICHERO,ref int lineasIguales)
        {
            bool valor = true;
            StreamWriter sw ;
            sw = File.CreateText(NUEVOFICHERO);

            try
            {
                for (int i = 0; i < fichero1.Count; i++)
                {
                    if (fichero1[i] == fichero2[i])
                    {
                        lineasIguales++;
                       sw.WriteLine((i + 1) + ";" + fichero1[i] + ";" + fichero2[i]);
                    }
                    else
                    {
                        if (fichero1[i]=="")
                        {
                            sw.WriteLine((i + 1) + ";" + ";" + fichero2[i]);
                        }
                        else
                        {
                            if (fichero2[i]=="")
                                sw.WriteLine((i + 1) + ";" + fichero1[i]+";");
                        }
                    }
                }
                    sw.Close();
                
            }catch(Exception e)
            {
                Console.WriteLine(e.Message);
                valor = false;
            }
            return valor;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    internal class CSFunciones
    {
        public const string FICHERO = "fichero.txt";
        public static bool ComprobarFichero()
        {
            bool valor =true;
            string FICHERO;
            try
            {
                Console.WriteLine("Introduce el nombre del fichero a trabajar");
                FICHERO = Console.ReadLine();
                while (!File.Exists(FICHERO))
                { 
                    Console.WriteLine("Lo siento el nombre de archivo introducido no existe. Vuelva a intentarlo:"); 
                    FICHERO= Console.ReadLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return valor;
        }
        public static int NumeroLineas(ref int numeroLineas)
        {
            StreamReader sr = new StreamReader(FICHERO);
            try
            {
                while (!sr.EndOfStream && sr.ReadLine().Length != 0)
                {
                    numeroLineas++;
                }
                sr.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return numeroLineas;
        }
        public static List<string> CrearVectorLineas(ref List<string> lineas)
        {
            StreamReader sr = new StreamReader(FICHERO);
            try
            {
                while(!sr.EndOfStream)
                    lineas.Add(sr.ReadLine());
                sr.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return lineas;
        }
        public static void ImprimirLineasDeseadas(ref List<string> lineas,ref int n)
        {
            if (n>lineas.Count)
            {
                for (int i = 0; i < lineas.Count; i++)
                {
                    Console.WriteLine(lineas[i]);
                }
            }
            else
            {
                for (int i = lineas.Count-n; i < lineas.Count; i++)
                {
                    Console.WriteLine(lineas[i]);
                }

            }
        }
    }
}

﻿namespace Ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*            Dado un nombre de un fichero y un número n de líneas entero positivo, mostrar por pantalla las n últimas líneas del fichero.
                            Si el fichero contiene menos de n líneas, se mostrarán todas.*/
            bool noerror=true;
            List<string> lineas = new List<string>();
            int n = 0,numeroLineas=0;
           
            noerror = CSFunciones.ComprobarFichero();

            Console.WriteLine("Dame el número de líneas a contar por el final para imprimir:");
            while(!int.TryParse(Console.ReadLine(),out n) || n<0)
                Console.WriteLine("Lo siento n debe de ser entero y positivo. Vuelva a intentarlo:");

            CSFunciones.NumeroLineas(ref numeroLineas);
            lineas = CSFunciones.CrearVectorLineas(ref lineas);
            CSFunciones.ImprimirLineasDeseadas(ref lineas,ref n);
        }
    }
}